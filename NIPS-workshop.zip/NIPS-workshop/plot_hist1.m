function plot_hist1(data1,data2,data1c,data2c,s1,s2)


figure1=figure;
subplot1 = subplot(2,1,1,'Parent',figure1,'FontWeight','bold','FontSize',14);

box(subplot1,'on');
grid(subplot1,'on');
hold(subplot1,'all');
hist([data1;data2]',10)
legend('k=50','k=1000')
% set(plot1(2),'LineWidth',2,'LineStyle','none','DisplayName','RWDISK');
% set(plot1(1),'LineWidth',2,'Color',[1 0 0],'DisplayName','METIS');
% Create xlabel
xlabel({s1},'FontWeight','bold','FontSize',14,'FontName','Arial');
% Create ylabel
ylabel({'Number of Nodes'},'FontWeight','bold','FontSize',14,...
'FontName','Arial');
subplot2 = subplot(2,1,2,'Parent',figure1,...
    'FontWeight','bold','FontSize',14);


hold(subplot2,'all');
grid on
% Create xlabel
hist([data1c;data2c]',10)
legend('k=50','k=1000')
xlabel(s2,'FontWeight','bold','FontSize',14);
% Create ylabel
ylabel('Number of Nodes','FontWeight','bold','FontSize',14);

% Create plot
legend(subplot2,'show');
colormap gray
end
