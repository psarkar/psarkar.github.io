[meanV50,maxV50,medianV50,nodes,maxinds50]=error_sample(L,A,Z50,alpha,100,[],0);
[meanV1000,maxV1000,medianV1000,nodes,maxinds1000]=error_sample(L,A,Z1000,alpha,100,nodes,0);
[meanV10000,maxV10000,medianV10000,nodes,maxinds10000]=error_sample(L,A,Z10000,alpha,100,nodes,0);
plot_hist(meanV50,meanV1000,meanV10000,medianV,medianV1000,medianV10000,'Mean error','Median error')